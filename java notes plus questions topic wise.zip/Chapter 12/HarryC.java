package codewithharry;

public class HarryC {
    public static void main(String[] args) {
        System.out.println("I am class harry c's main method!");
    }
}
