package codewithharry.friends;

public class HarryFriend {
    public static void main(String[] args) {
        System.out.println("I am class harry friend's main method!");
    }
}
